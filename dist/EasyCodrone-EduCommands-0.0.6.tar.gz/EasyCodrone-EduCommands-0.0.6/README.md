# EasyCodroneEduCommands makes using codrone-edu more straightforward when moving the drone. It pretty much just makes it less tedious.
